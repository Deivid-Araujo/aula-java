package br.com.fiap.jogo;

import javax.swing.JOptionPane;

public class Jogo {
	
	public static void main(String[] args) {
		
		
		
//		
//		String nome = JOptionPane.showInputDialog("Digite o nome do jogador");
//		Jogador jogador = new Jogador(nome);
//		
//		Jogador jogador2 = new Jogador(nome);
		
		Jogador.mostrarTempo();
		
		JOptionPane.showMessageDialog(null, "Ola");
		
		//Math.PI;
		
//		jogador.receceberAntidoto();
//		System.out.println(jogador.toString());
//		System.out.println(jogador2.toString());
//		
//		jogador.receberDano(10);
//		
//		jogador.receberCura(20);
//		
//		jogador.ganharExperiencia(50);
//
//		jogador.receceberAntidoto();
//		System.out.println(jogador);
//		
		

		

		
		
	}

}
