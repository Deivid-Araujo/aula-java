package br.com.fiap.jogo;

public class JogadorRpg extends Jogador {

	@Override
	public void mover() {
				
	}
	

}
