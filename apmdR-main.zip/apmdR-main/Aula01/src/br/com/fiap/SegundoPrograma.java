package br.com.fiap;

import javax.swing.JOptionPane;

public class SegundoPrograma {

	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Segundo Programa");
	}

}
