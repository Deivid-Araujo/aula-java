package br.com.fiap.rh;

public class Auxiliar extends Empregado {

	@Override
	public double calcularSalario() {
		// TODO Auto-generated method stub
		return 0;
	}

}
