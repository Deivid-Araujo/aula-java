package br.com.fiap.veterinario;

public class Gato {
	
	String nome;
	String cor;
	int tamanho;
	char genero;
	
	void miar(){
		System.out.println(nome + " diz Miau");
	}

}
