package br.com.fiap;

public class PrimeiroPrograma{

	public static void main(String[] args) {
		System.out.println("Vamos para o intevalo");
	}
	
}
